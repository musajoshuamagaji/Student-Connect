// Put your deployed backend URL here (no trailing slash), e.g. https://student-connect-api.onrender.com
window.API_URL = "https://YOUR-BACKEND-URL";
