# Student Connect 👨‍🎓
AI tutor, PDF summaries and study timetable for students. **Powered by Dev Joshua**

## Structure
- `www/` the app (HTML). `www/config.js` holds your backend URL.
- `server/` small backend that keeps your Claude API key secret.
- `.github/workflows/build-apk.yml` builds the Android APK on GitHub.

## Step 1: Deploy the backend
1. Get an API key at https://openrouter.ai/keys (add credits if your model is paid).
2. Deploy the `server/` folder on Render, Railway or similar (Node, start command `npm start`).
3. Add environment variables `OPENROUTER_API_KEY` (your key) and `MODEL` (a model ID copied exactly from https://openrouter.ai/models).
4. Open your backend URL. You should see "Student Connect API is running".

## Step 2: Set the URL
Edit `www/config.js` and replace `https://YOUR-BACKEND-URL` with your backend URL.

## Step 3: Push to GitHub and build the APK
1. Create a new repository on github.com and upload all these files (keep the `.github` folder).
2. Go to **Actions → Build APK → Run workflow** (it also runs on every push to `main`).
3. When it finishes, open the run and download **student-connect-apk** from Artifacts.
4. Unzip it and install `app-debug.apk` on an Android phone.

## Notes
- Never put your API key in `www/` or the repository.
- This builds a debug APK, fine for testing and sharing within your school. A Play Store release needs a signed release build.
- Test the web version by opening `www/index.html` after setting `config.js`.
