import express from "express";
import cors from "cors";

const app = express();
app.use(cors());
app.use(express.json({ limit: "1mb" }));

// Very simple per-IP limit: 20 requests per minute
const hits = new Map();
app.use("/api", (req, res, next) => {
  const ip = req.headers["x-forwarded-for"] || req.ip;
  const now = Date.now();
  const list = (hits.get(ip) || []).filter((t) => now - t < 60000);
  if (list.length >= 20) return res.status(429).json({ error: "Too many requests" });
  list.push(now);
  hits.set(ip, list);
  next();
});

app.get("/", (_req, res) =>
  res.send("Student Connect API is running. Powered by Dev Joshua")
);

app.post("/api/chat", async (req, res) => {
  const messages = req.body && req.body.messages;
  if (!Array.isArray(messages) || !messages.length || messages.length > 14) {
    return res.status(400).json({ error: "Bad request" });
  }

  const clean = messages.map((m) => ({
    role: m.role === "assistant" ? "assistant" : "user",
    content: String(m.content || "").slice(0, 45000),
  }));

  if (!process.env.OPENROUTER_API_KEY || !process.env.MODEL) {
    return res.status(500).json({ error: "Server not configured" });
  }

  try {
    const r = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: "Bearer " + process.env.OPENROUTER_API_KEY,
      },
      body: JSON.stringify({
        model: process.env.MODEL,
        max_tokens: 1000,
        messages: clean,
      }),
    });

    const data = await r.json();
    if (!r.ok) {
      console.error("OpenRouter error:", JSON.stringify(data));
      return res.status(502).json({ error: "AI error" });
    }

    const text = data.choices?.[0]?.message?.content || "";
    res.json({ text });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Server error" });
  }
});

app.listen(process.env.PORT || 3000, () =>
  console.log("Student Connect API ready")
);
